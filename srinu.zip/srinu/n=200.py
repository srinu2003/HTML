n=200
s = "srinivas"